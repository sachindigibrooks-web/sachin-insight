uCaseSpot Checkout Tutorial – Premiere Pro project package
===========================================================

CONTENTS
  uCaseSpot_Checkout_Tutorial_Premiere.xml   -> the editable timeline (import this)
  media/                                     -> every clip used on the timeline
  EDITOR_TIMELINE.csv / EDITOR_TIMELINE.md   -> timecode sheet of every clip and voice line

HOW TO OPEN IN PREMIERE PRO
  1. Unzip the whole folder. Keep the XML file and the "media" folder side by side.
  2. Premiere Pro > File > Import... > select uCaseSpot_Checkout_Tutorial_Premiere.xml
     A bin with the sequence "uCaseSpot Checkout Tutorial – Fast Voice" is created. Double-click it.
  3. If Premiere shows "Link Media": click "Locate", open the media folder, select the file it asks for,
     click OK. All other files relink automatically.

TRACK LAYOUT
  V1  34 scene clips (title cards, website recording, PayPal steps), cut back-to-back
  V2  REFERENCE_final_render.mp4 – disabled. Select it and press Shift+E to compare with the final video.
  A1  27 voiceover clips (level +4 dB)
  A2  background music, royalty-free, generated (level -12 dB)
  A3  whoosh sound at each section change
  A4  ding at the two key moments (order total, order number)

FINISHING TOUCHES (were in the final render; add as you like)
  - Transitions at each section start (rows marked "transition in" in EDITOR_TIMELINE):
    place the playhead on the cut and press Ctrl+D / Cmd+D (Cross Dissolve), or drag
    Push / Iris Round / Dip to Black from Effects > Video Transitions. Length about 10–12 frames.
  - Music ducking: select the voice clips > Essential Sound > Dialogue; select the music >
    Essential Sound > Music > Ducking > "Generate Keyframes".
  - Export: File > Export > Media > H.264, Match Source – High bitrate, 1920x1080, 30 fps.

NOTES
  - Highlights, cursor, step labels and the animated title/step cards are part of the video clips
    (not editable text layers). Ask if you need text-free card backgrounds or separate text layers.
  - The music and sound effects are original and royalty-free.
